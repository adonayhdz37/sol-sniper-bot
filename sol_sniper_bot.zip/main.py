# main.py

import asyncio
from core.telegram import telegram_polling
from core.wallet_monitor import wallet_monitor_loop

if __name__ == "__main__":
    try:
        asyncio.run(asyncio.gather(
            telegram_polling(),
            wallet_monitor_loop()
        ))
    except KeyboardInterrupt:
        print("🛑 Bot detenido.")
